from binary_tree import BinaryTree


bt = BinaryTree()

bt.insert(5)
bt.insert(6)
bt.insert(7)
bt.insert(8)
bt.insert(9)

bt.delete(6)

bt.inorder()

