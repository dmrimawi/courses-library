def square(x):
    return x * x

def print_square(x):
    result = square(x)
    print(f"The square of {x} is {result}")


x = int(input("Enter x: "))
print_square(x)

print("hello")

# W3L1_Calls
# x = 5
# print_square(5)

# Square (5)
# return 5 * 5 = 25

# Print_square (5)
# result = 25
# ...

# Display
# The square of 5 is 25
# hello
