# Start
# Ask the user to enter num1
# Input num1
num1 = int(input("Please enter num1: "))
# Ask the user to enter num2
# Input num2
num2 = int(input("Please enter num2: "))
# Calculate sum as num1 + num2
sum = num1 + num2
# Display sum
print(f"The sum of {num1} and {num2} is: {sum}")
# End