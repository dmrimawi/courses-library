# F = C * 9/5 + 32.
# Start
# Ask the user to enter the temp in C
# Input c
c = float(input("Enter the temp in c: "))
# Calculate F as c * (9 / 5) + 32
f = c * (9/5) + 32
# print (F)
print(f)
# End