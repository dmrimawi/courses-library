arr = [20, 16, 2, 55, 12, 10]
# print("\n".join(arr))

for it in arr:
    print(it)

print("_" * 60)

# for i=0 to 6 do
#   display arr[i]
# end for
print(len(arr))
print("_" * 60)
for i in range(len(arr)): # [0,1,2,3,4,5]
    print(arr[i])
print("_" * 60)
# Range
for i in range(0, 6, 2):
    print(i)
print("_" * 60)
print(arr[-1])


