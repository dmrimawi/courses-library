# Check if a character is inside a string or not.
ch = input("Enter the char: ")
st = input("Enter the string: ")
if ch in st:
    print(f"{ch} is in {st}")
else:
    print("Not found")
