# Conditions
# && -> and
# || -> or
# ! -> not
score = float(input("Enter the score: "))
if score >= 90:
    print("A")
elif score >= 80:
    print("B")
else:
    print("C or below")
