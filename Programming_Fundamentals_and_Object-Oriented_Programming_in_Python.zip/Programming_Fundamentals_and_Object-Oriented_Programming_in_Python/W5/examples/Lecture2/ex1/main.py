from teacher import Teacher
from student import Student

muhsen = Student("s123", "Computer Science", "Muhsen", 19)
muhsen.introduce()

suad = Teacher("Suad", 26, "t123", ["Science", "Math"], "Math", 2000)
suad.introduce()
