class Shape:
    def __init__(self):
        pass

    def area(self):
        pass
    